// Star Wars Characters (DATA)
// =============================================================
var tableReservations = [
  {
    name: "",
    phoneNum: "",
    email: "",
    id: ""
  }
];

module.exports = tableReservations;